import React from "react";
import "./Services.css";  // Assuming you will create this CSS file
import { Link } from "react-router-dom";  // Add this import


const Services = () => {
  return (
    <section id="services">
      <div className="container">
        <h2 className="text-center my-5">Our Services</h2>

        <div className="row">
          {/* Cardiology Service */}
          <div className="col-md-3 mb-4">
            <div className="service-card">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzfH_gIGl4Mo1J3Jl25yV-hcpCKuKbRxTxxA&s"
                alt="Cardiology"
                className="service-image"
              />
              <div className="service-info">
                <h3>Cardiology</h3>
                <p>
                  Expert care for heart-related conditions, including
                  diagnostics, treatments, and prevention.
                </p>
                <Link to="/Create" className="btn btn-primary">Book Appointment</Link>
              
              </div>
            </div>
          </div>

          {/* Dermatology Service */}
          <div className="col-md-3 mb-4">
            <div className="service-card">
              <img
                src=""
                className="service-image"
              />
              <div className="service-info">
                <h3>Dermatology</h3>
                <p>Comprehensive skin care services for all skin types and conditions.</p>
                <Link to="/Create2" className="btn btn-primary">Book Appointment</Link>
                
              </div>
            </div>
          </div>

          {/* Pediatrics Service */}
          <div className="col-md-3 mb-4">
            <div className="service-card">
              <img
                src=""
                className="service-image"
              />
              <div className="service-info">
                <h3>Pediatrics</h3>
                <p>Child healthcare services to support growth, development, and well-being.</p>
                <Link to="/Create3" className="btn btn-primary">Book Appointment</Link>
              </div>
            </div>
          </div>

          {/* Orthopedics Service */}
          <div className="col-md-3 mb-4">
            <div className="service-card">
              <img
                src=""
                alt="Orthopedics"
                className="service-image"
              />
              <div className="service-info">
                <h3>Orthopedics</h3>
                <p>
                  Treatment and care for bone and joint disorders with a focus on recovery and mobility.
                </p>
                <Link to="/Create4" className="btn btn-primary">Book Appointment</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;

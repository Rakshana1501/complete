import React, { useState, useEffect, useRef } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

// Import Components
import LoginPage from './LoginPage';  
import HomePage from './HomePage';
import AboutPage from './AboutPage';
import ServicesPage from './Services';
// import LoginPage from './LoginPage';
import AppointmentPage from './CreateAppointment';

const App = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [textColor, setTextColor] = useState("#ff4081");
  const homeRef = useRef(null); // Reference for scrolling to Home section

  // Color change every 1.5 seconds
  useEffect(() => {
    const colors = ["#ff4081", "#00d4ff", "#ffeb3b", "#76ff03", "#ff5722"];
    const interval = setInterval(() => {
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      setTextColor(randomColor);
    }, 1500);

    return () => clearInterval(interval); // Cleanup on unmount
  }, []);

  // Toggle menu visibility on mobile
  const toggleMenu = () => setMenuOpen(!menuOpen);

  // Scroll to Home section
  const handleHomeClick = (e) => {
    e.preventDefault();
    homeRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <Router>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minHeight: '100vh', margin: 0, backgroundColor: '#222', fontFamily: 'Arial, sans-serif', color: 'white' }}>

        {/* Navbar */}
        <div className="header-nav-container" style={{ width: '100%', position: 'fixed', top: 0, zIndex: 1000, backgroundColor: '#004274', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', padding: '10px 20px' }}>
          <header style={{ textAlign: 'center', marginBottom: '10px' }}>
            <div className="word" style={{ fontSize: '1.8em', fontWeight: 'bold', color: textColor }}>⚕️ Vasan Health Care</div>
          </header>
          <nav style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '50px' }}>
            <div className="logo" style={{ fontSize: '25px', color: 'white' }}>BeHealthy</div>
            <ul className="menuList" style={{
              display: 'flex', gap: '15px', listStyle: 'none', padding: 0, margin: 0, alignItems: 'center',
              flexDirection: 'row', transition: 'max-height 0.3s ease-in-out', maxHeight: menuOpen ? '200px' : '0', overflow: 'hidden',
            }}>
              <li><Link to="/" onClick={handleHomeClick} style={{ color: 'white', textDecoration: 'none', fontSize: '0.9em', padding: '5px 10px' }}>Home</Link></li>
              <li><Link to="/about" style={{ color: 'white', textDecoration: 'none', fontSize: '0.9em', padding: '5px 10px' }}>About</Link></li>
              <li><Link to="/services" style={{ color: 'white', textDecoration: 'none', fontSize: '0.9em', padding: '5px 10px' }}>Services</Link></li>
              <li><a href="#footer" style={{ color: 'white', textDecoration: 'none', fontSize: '0.9em', padding: '5px 10px' }}>Contact</a></li>
            </ul>
            <div className="menu-icon" onClick={toggleMenu} style={{
              display: 'block', fontSize: '1.5em', color: 'white', cursor: 'pointer',
            }}>
              <i className="fa fa-bars"></i>
            </div>
          </nav>
        </div>

        {/* Routes */}
        <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/appointment" element={<AppointmentPage />} />
          </Routes>

      </div>
    </Router>
  );
};

export default App;

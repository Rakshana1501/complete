import React from 'react';

// Inline CSS-in-JS for styling
const styles = {
  aboutUs: {
    padding: '40px',
    backgroundColor: '#f4f4f4',
    color: '#333',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  aboutContent: {
    display: 'flex',
    flexDirection: 'row', // Default to row layout on desktop
    flexWrap: 'wrap',
    gap: '20px',
    justifyContent: 'center',
    alignItems: 'center',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  aboutImage: {
    flex: 1,
    minWidth: '300px', // Ensure the image does not get too small
  },
  aboutImageImg: {
    width: '100%',
    maxWidth: '600px',
    borderRadius: '8px',
    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
  },
  aboutText: {
    flex: 1,
    minWidth: '300px', // Ensure text doesn't shrink too small
  },
  aboutTextH2: {
    fontSize: '2em',
    marginBottom: '20px',
    color: 'black',
    textAlign: 'center', // Center text on mobile and desktop
  },
  aboutTextP: {
    fontSize: '1.1em',
    lineHeight: '1.6',
    textAlign: 'center', // Center text on mobile and desktop
  },
  buttonContainer: {
    marginTop: '20px',
    textAlign: 'center',
  },
  button: {
    padding: '10px 20px',
    fontSize: '1.1em',
    backgroundColor: '#004274',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
  },
  buttonHover: {
    backgroundColor: '#00324e',
  },
  // Media Queries for responsiveness
  '@media (max-width: 768px)': {
    aboutContent: {
      flexDirection: 'column', // Stack the image and text vertically on mobile
      textAlign: 'center',
    },
    aboutImage: {
      maxWidth: '80%', // Scale down image width on mobile
      marginBottom: '20px',
    },
    aboutTextH2: {
      fontSize: '1.5em', // Adjust title size on smaller screens
    },
    aboutTextP: {
      fontSize: '1em', // Adjust paragraph size on smaller screens
    },
  },
};

const AboutPage = () => {
  return (
    <section style={styles.aboutUs}>
      <div style={styles.aboutContent}>
        <div style={styles.aboutImage}>
          <img
            src="https://img.freepik.com/free-photo/woman-writing-prescription-clipboard-listening-doctor-instructions-pediatrician-specialist-medicine-with-mask-providing-health-care-services-consultation-treatment-hospital-covid-19_482257-14519.jpg?semt=ais_hybrid"
            alt="Doctors"
            style={styles.aboutImageImg}
          />
        </div>
        <div style={styles.aboutText}>
          <h2 style={styles.aboutTextH2}>About Us</h2>
          <p style={styles.aboutTextP}>
            Vasan Health Care is a leading healthcare provider committed to offering high-quality medical services and comprehensive health solutions. 
            With a focus on patient care, Vasan Health Care integrates advanced technology with a compassionate approach to improve the well-being of individuals.
            The organization provides a wide range of services, including preventive care, diagnostics, specialized treatments, and wellness programs,
            all tailored to meet the unique needs of each patient. Through a network of state-of-the-art facilities and a team of experienced healthcare professionals,
            Vasan Health Care strives to promote health, prevent diseases, and enhance the quality of life for people of all ages.
          </p>
        </div>
      </div>
      <div style={styles.buttonContainer}>
        <a href="https://www.youtube.com/watch?v=xGPCphilK9o" target="_blank" rel="noopener noreferrer">
          <button
            style={styles.button}
            onMouseOver={(e) => (e.target.style.backgroundColor = styles.buttonHover.backgroundColor)}
            onMouseOut={(e) => (e.target.style.backgroundColor = styles.button.backgroundColor)}
          >
            Go to YouTube
          </button>
        </a>
      </div>
    </section>
  );
};

export default AboutPage;

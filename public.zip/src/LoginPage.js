import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    backgroundImage: 'url("https://www.primehealthcare.com/wp-content/uploads/2023/06/Website-image.jpeg")',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    textAlign: 'center',
  },
  button: {
    padding: '10px 20px',
    fontSize: '16px',
    backgroundColor: 'skyblue',
    color: 'white',
    textDecoration: 'none',
    borderRadius: '5px',
    marginTop: '20px',
    border: '2px solid transparent;'
  },
};

const LoginPage = () => {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    // Simple validation
    if (!name || !password) {
      setError('Please enter both Name and Password');
      return;
    }

    console.log('Login attempt:', { name, password });
    setError('');
    alert('Welcome To Vasan Website');
    navigate('/Home'); // Redirect to Home page after successful login
  };

  return (
    <div style={styles.container}>
      <div style={{ maxWidth: '400px', padding: '20px', border: '1px solid #ddd', borderRadius: '10px', backgroundColor: '#ffff', textAlign: 'center' }}>
        <h2>Login</h2>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ marginBottom: '15px' }}>
            <label>Name:</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={{ padding: '8px', fontSize: '16px', width: '100%', marginTop: '5px', border: '1px solid #ccc', borderRadius: '5px' }}
              required
            />
          </div>
          <div style={{ marginBottom: '15px' }}>
            <label>Password:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={{ padding: '8px', fontSize: '16px', width: '100%', marginTop: '5px', border: '1px solid #ccc', borderRadius: '5px' }}
              required
            />
          </div>
          {error && <p style={{ color: 'red', fontSize: '14px', marginTop: '10px' }}>{error}</p>}
          <button type="submit" style={styles.button}>Login</button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;

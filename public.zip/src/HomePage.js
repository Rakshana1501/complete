import React, { useEffect, useState, useRef } from 'react';

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [textColor, setTextColor] = useState("#ff4081");
  const homeRef = useRef(null); // Create a reference for the home section

  useEffect(() => {
    const colors = ["#ff4081", "#00d4ff", "#ffeb3b", "#76ff03", "#ff5722"];
    const interval = setInterval(() => {
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      setTextColor(randomColor);
    }, 1500);

    return () => clearInterval(interval); // Cleanup on unmount
  }, []);

  // Toggle menu visibility on mobile
  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  // Scroll to the top (Home) when the link is clicked
  const handleHomeClick = (e) => {
    debugger
    e.preventDefault();
    if (homeRef.current) {
      homeRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div ref={homeRef} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', minHeight: '100vh', margin: 0, backgroundColor: '#222', fontFamily: 'Arial, sans-serif', color: 'white' }}>

      {/* Navbar */}
      <div className="header-nav-container" style={{ width: '100%', position: 'fixed', top: 0, zIndex: 1000, backgroundColor: '#004274', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', padding: '10px 20px' }}>
        <header style={{ textAlign: 'center', marginBottom: '10px' }}>
          <div className="word" style={{ fontSize: '1.8em', fontWeight: 'bold', color: textColor }}>⚕️ Vasan Health Care</div>
        </header>
        <nav style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '50px' }}>
          <div className="logo" style={{ fontSize: '25px', color: 'white' }}>BeHealthy</div>
          {/* Mobile Menu Toggle */}
          <ul className="menuList" style={{
            display: 'flex',
            gap: '15px',
            listStyle: 'none',
            padding: 0,
            margin: 0,
            alignItems: 'center',
            flexDirection: 'row', // Horizontal layout for larger screens
            transition: 'max-height 0.3s ease-in-out',
            maxHeight: menuOpen ? '200px' : '0',  // Control visibility of menu on mobile
            overflow: 'hidden',
          }}>
            <li><a href="/" onClick={handleHomeClick} style={{ color: 'white', textDecoration: 'none', fontSize: '0.9em', padding: '5px 10px' }}>Home</a></li>
            <li><a href="./AboutPage" style={{ color: 'white', textDecoration: 'none', fontSize: '0.9em', padding: '5px 10px' }}> About</a></li>
            <li><a href="./Services" style={{ color: 'white', textDecoration: 'none', fontSize: '0.9em', padding: '5px 10px' }}>Services</a></li>
            <li><a href="#footer" style={{ color: 'white', textDecoration: 'none', fontSize: '0.9em', padding: '5px 10px' }}>Contact</a></li>
          </ul>
          <div className="menu-icon" onClick={toggleMenu} style={{
            display: 'block',
            fontSize: '1.5em',
            color: 'white',
            cursor: 'pointer',  // Add pointer cursor for better UX
          }}>
            <i className="fa fa-bars"></i>
          </div>
        </nav>
      </div>

      {/* Carousel */}
      <div className="carousel-container" style={{ position: 'relative', width: '100%', height: '100vh', zIndex: 10, overflow: 'hidden' }}>
        <div id="caro" className="carousel slide" data-bs-ride="carousel" data-bs-interval="1000">
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img src="https://wallpapers.com/images/hd/doctor-with-globe-in-hand-hd-medical-dff7ahiwc5xsfjm0.jpg" className="d-block w-100" alt="First Image" />
            </div>
            <div className="carousel-item">
              <img src="https://images4.alphacoders.com/695/695589.jpg" className="d-block w-100" alt="Second Image" />
            </div>
            <div className="carousel-item">
              <img src="https://wallpapers.com/images/featured/hd-medical-woaib193g5o6sx5g.jpg" className="d-block w-100" alt="Third Image" />
            </div>
            <div className="carousel-item">
              <img src="https://wallpapers.com/images/hd/hd-medical-syringe-and-tiny-bottle-jprju510q7gx0t02.jpg" className="d-block w-100" alt="Fourth Image" />
            </div>
          </div>
          <button className="carousel-control-prev" type="button" data-bs-target="#caro" data-bs-slide="prev">
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button className="carousel-control-next" type="button" data-bs-target="#caro" data-bs-slide="next">
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
